js.namespace('JQ.Widget.DiagramEditor');

ns.Control = {
    control_id: 'DiagramEditor.control',
    header: {
        params: [
            {
                qname: 'Palette',
                description: '',
                type: 'setting',
                editor_type: 'code',
                editor_options: { type: 'json' },
                default_value: ''
            },
            {
                qname: 'LinkParams',
                description: '',
                type: 'setting',
                editor_type: 'code',
                editor_options: { type: 'json' },
                default_value: ''
            },
            {
                qname: 'Diagram',
                description: '',
                type: 'field',
                editor_type: 'code',
                editor_options: { type: 'json' },
                default_value: ''
            },
            {
                qname: 'ReadOnly',
                description: '',
                type: 'field',
                editor_type: 'boolean',
                default_value: false
            },
            {
                qname: 'Minimap',
                qnameRU: 'Включить_миникарту',
                description: '',
                type: 'field',
                editor_type: 'boolean',
                default_value: false,
                is_optional: true
            },
            {
                qname: 'BgColor',
                qnameRU: 'Цвет_фона',
                description: '',
                type: 'setting',
                editor_type: 'textColorpicker',
                default_value: '',
                group: 'style'
            }
        ],
        events: []
    },
    type: 'DiagramEditor',
    widget: {
        script: 'DiagramEditor.widget',
        name: 'DiagramEditor'
    }
}
